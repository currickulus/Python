





#                         Mouse Python Script
#                     Colorado State University Global
#                         Thomas R Dewing
#                        ITS320:Basic Programming
#                        Dr. Ray Fernandez
#                        June, 16, 2024
#









print("              (\\_")
print("             /   :")
print("    _)      /   _  >")
print("   (       /    _)=")
print("    '_    /   _/")
print("      '__(____)_")


